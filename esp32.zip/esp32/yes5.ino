#include <ArduinoJson.h>
#include <DNSServer.h>
#include <FirebaseESP32.h>
#include <HTTPClient.h>
#include <Preferences.h>
#include <TFT_eSPI.h>
#include <WebServer.h>
#include <WebSocketsClient.h>
#include <WiFi.h>
#include <WiFiUdp.h>
#include <time.h>
#include "Duckplayingcomputer.h"
#include "SleepingDuck.h"
#include "Duckplaygame.h"
#include "MagicDuckQuote.h"

// ==============================
// 🛠️ CONFIGURATION (โหมดทดสอบ)
// ==============================
#define GACHA_TEST_MODE false // ปิดโหมดทดสอบ เพื่อใช้งานจริง (สุ่ม 1-2 ครั้งต่อวัน)

// Touch Library Removed for Auto-Slide

// ==============================
// Firebase Config
// ==============================
#define FIREBASE_HOST                                                          \
  "recharge-app-77aa8-default-rtdb.asia-southeast1.firebasedatabase.app"
#define FIREBASE_AUTH "5MHOQkLpitfQDMMc4jqOzBByKeAABbqXcAalXqUh"

FirebaseData fbdo;
FirebaseAuth auth;
FirebaseConfig config;
String user_uid = "";

// ==============================
// WiFi Setup (Captive Portal)
// ==============================
const byte DNS_PORT = 53;
IPAddress apIP(192, 168, 4, 1);
DNSServer dnsServer;
WebServer server(80);
Preferences preferences;
String ssid = "";
String password = "";
bool isAPMode = false;

// ==============================
// BOOT Button (GPIO 0) - Factory Reset
// ==============================
#define BOOT_BTN_PIN 0  // GPIO0 = ปุ่ม BOOT บนบอร์ด ESP32
unsigned long bootBtnPressStart = 0;
bool bootBtnWasPressed = false;

// ==============================
// WebSocket + TFT + UDP
// ==============================
WebSocketsClient wsClient;
TFT_eSPI tft = TFT_eSPI();
WiFiUDP udp;
const int WS_PORT = 8765;
const int UDP_PORT = 4210;
String pcHost = "";
bool pcFound = false;

// ตัวแปรเก็บค่าฮาร์ดแวร์
int cpu_usage = 0, cpu_temp = 0;
int gpu_usage = 0, gpu_temp = 0;
int ram_usage = 0;
int pc_uptime = 0;
bool pc_online = false;

// ตัวแปรใหม่ตามแผน
int wifi_rssi = 0;
bool gaming_active = false;
String gaming_game_name = "";
float daily_cost_fb = 0.0;
int daily_mins_fb = 0;
String weather_pm25 = "PM2.5: --";
uint32_t weather_temp_color = TFT_CYAN;  // เริ่มต้นสีฟ้า (หนาว)
uint32_t weather_pm25_color = TFT_GREEN; // เริ่มต้นสีเขียว (ปลอดภัย)
float net_dl = 0.0, net_ul = 0.0;
String current_date_str = "";
String current_month_str = "";

// ตัวแปรใหม่สำหรับ Action Pages & Apps
int current_page = 0; // 0 = Dashboard, 1 = Apps & Control
int timer_left = 0;
String top_cpu_apps[3] = {"", "", ""};
String top_ram_apps[3] = {"", "", ""};
unsigned long lastPageSwitch = 0;

// เพิ่มตัวแปรคำนวณค่าไฟ
float pc_watt = 0.0;
float unit_price = 0.0;
bool setupFetched = false;

// ==============================
// Smart System (Weather, Gaming, AFK)
// ==============================
String weather_temp = "WAIT...";
String weather_icon = "WEATHER";
unsigned long lastWeatherCheck = 0;
String geo_lat = "";
String geo_lon = "";

unsigned long ssStartTime = 0; // จับเวลา AFK

bool wsConnected = false;
unsigned long lastDraw = 0;
unsigned long lastFbCheck = 0;
unsigned long lastSetupCheck = 0;

// ตัวแปรเก็บสถานะ (เพื่อป้องกันจอกระพริบ)
int last_cpu_gauge = -1;
int last_gpu_gauge = -1;
int last_ram_gauge = -1;
int last_uptime = -1;
float last_watt = -1.0;
int last_sec = -1;
int last_wifi_bars = -1;
bool last_pc_online = false;
bool last_gaming_active = false;
String last_game_name = "";
int last_timer = -1;
String last_weather_temp = "";
String last_weather_pm25 = "";

// ==============================
// Screensaver State & Gacha Quote
// ==============================
int last_known_cpu = -1;                 // เก็บค่า CPU ล่าสุด
unsigned long last_pc_activity = 0;      // จับเวลาว่าคอมขยับล่าสุดตอนไหน
bool isGachaPlaying = false;
unsigned long gachaIntroStart = 0;
void drawMagicDuckQuote();

String currentGame = ""; // เก็บชื่อเกม ถ้าว่างแปลว่าไม่ได้เล่น
bool isGameIntroPlaying = false; 
unsigned long gameIntroStart = 0;
void drawGameIntroAnim(unsigned long frame);
bool isWeatherIntroPlaying = false;
unsigned long weatherIntroStart = 0;
int weatherIntroType = 0; // 1 = Rain, 2 = PM2.5
bool rain_active = false;
bool pm25_active = false;
void drawWeatherIntroAnim(int type, unsigned long timeElapsed);
bool mouseIdle = true; // บัคแก้แล้ว: บังคับให้คิดว่าหลับตั้งแต่ต้น เพื่อให้ตอนเปิดบอร์ดถ้าเล่นคอมอยู่ มันจะจับการตั้งค่าเปลี่ยนเป็น False แล้วตื่นได้!
bool ssActive = false;
bool ssShowClock = true;
unsigned long ssLastSwitch = 0;
unsigned long animeFrame = 0;
bool ssClockInited = false;
bool uiInited = false;

// ==============================
// HTML Captive Portal
// ==============================
const char index_html[] PROGMEM = R"rawliteral(
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Board Setup</title>
    <link href="https://fonts.googleapis.com/css2?family=Prompt:wght@300;400;600;700&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Prompt', sans-serif; min-height: 100vh; background: #f0ece8; display: flex; align-items: center; justify-content: center; padding: 20px; }
        .card { background: #5b4fcf; border-radius: 32px; padding: 36px 28px 28px; width: 100%; max-width: 360px; box-shadow: 0 20px 60px rgba(91,79,207,0.35); position: relative; overflow: hidden; }
        .blob1 { position: absolute; top: -30px; right: -20px; width: 120px; height: 120px; background: rgba(255,255,255,0.08); border-radius: 50%; }
        .blob2 { position: absolute; top: 20px; right: 60px; width: 60px; height: 60px; background: rgba(255,255,255,0.06); border-radius: 50%; }
        .blob3 { position: absolute; bottom: -20px; left: -20px; width: 100px; height: 100px; background: rgba(255,200,100,0.12); border-radius: 50%; }
        .header { position: relative; z-index: 1; margin-bottom: 28px; }
        .greeting { color: rgba(255,255,255,0.7); font-size: 13px; font-weight: 300; margin-bottom: 4px; }
        .title { color: #fff; font-size: 24px; font-weight: 700; line-height: 1.2; }
        .title span { color: #ffd166; }
        .form-section { background: #f0ece8; border-radius: 24px; padding: 24px 20px; position: relative; z-index: 1; }
        .form-label { font-size: 11px; font-weight: 600; color: #9b8ea0; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 8px; display: block; }
        .input-wrap { background: #fff; border-radius: 14px; padding: 14px 16px; margin-bottom: 16px; border: 2px solid transparent; transition: border-color 0.2s; display: flex; align-items: center; gap: 10px; }
        .input-wrap:focus-within { border-color: #5b4fcf; }
        .input-icon { font-size: 16px; }
        .input-wrap input { border: none; outline: none; background: transparent; font-family: 'Prompt', sans-serif; font-size: 14px; color: #3d3060; width: 100%; }
        .input-wrap input::placeholder { color: #c5bdd0; }
        .btn { width: 100%; padding: 15px; background: #5b4fcf; color: #fff; border: none; border-radius: 14px; font-family: 'Prompt', sans-serif; font-size: 15px; font-weight: 600; cursor: pointer; margin-top: 4px; display: flex; align-items: center; justify-content: center; gap: 8px; box-shadow: 0 6px 20px rgba(91,79,207,0.4); }
        .badge { display: inline-flex; align-items: center; gap: 6px; background: rgba(255,255,255,0.15); border-radius: 20px; padding: 5px 12px; color: rgba(255,255,255,0.9); font-size: 12px; margin-bottom: 18px; }
        .dot { width: 7px; height: 7px; background: #7dffb3; border-radius: 50%; animation: pulse 1.5s infinite; }
        @keyframes pulse { 0%,100%{opacity:1} 50%{opacity:0.4} }
        .hint { text-align: center; margin-top: 14px; font-size: 12px; color: #9b8ea0; }
        .hint a { color: #5b4fcf; text-decoration: none; font-weight: 600; }
    </style>
</head>
<body>
    <div class="card">
        <div class="blob1"></div><div class="blob2"></div><div class="blob3"></div>
        <div class="header">
            <div class="badge"><div class="dot"></div> AP Mode Active</div>
            <p class="greeting">ยินดีต้อนรับสู่</p>
            <h1 class="title">ตั้งค่า <span>WiFi</span><br>ให้น้องบอร์ด</h1>
        </div>
        <div class="form-section">
            <label class="form-label">ชื่อ WiFi (SSID)</label>
            <div class="input-wrap">
                <span class="input-icon">📶</span>
                <input type="text" id="ssid" placeholder="กรอกชื่อ WiFi ของคุณ" required>
            </div>
            <label class="form-label">รหัสผ่าน WiFi</label>
            <div class="input-wrap">
                <span class="input-icon">🔒</span>
                <input type="password" id="password" placeholder="กรอกรหัสผ่าน WiFi" required>
            </div>
            <label class="form-label">รหัสเครื่อง (Setup Code)</label>
            <div class="input-wrap">
                <span class="input-icon">🔑</span>
                <input type="text" id="uid" placeholder="ก๊อปปี้รหัสจากหน้าเว็บมาใส่" required>
            </div>
            <button class="btn" onclick="saveWifi()">🚀 บันทึกและเชื่อมต่อ</button>
            <p class="hint">ถ้าไม่เด้งอัตโนมัติ → <a href="http://192.168.4.1">กดที่นี่</a></p>
        </div>
    </div>
    <script>
    function saveWifi() {
        const ssid = document.getElementById('ssid').value;
        const pass = document.getElementById('password').value;
        const uid = document.getElementById('uid').value;
        if (!ssid) return;
        const form = document.createElement('form');
        form.method = 'POST'; form.action = '/save';
        const i1 = document.createElement('input'); i1.name='ssid'; i1.value=ssid; form.appendChild(i1);
        const i2 = document.createElement('input'); i2.name='password'; i2.value=pass; form.appendChild(i2);
        const i3 = document.createElement('input'); i3.name='uid'; i3.value=uid; form.appendChild(i3);
        document.body.appendChild(form); form.submit();
    }
    </script>
</body>
</html>
)rawliteral";

// ==============================
// NTP Sync & Date Utils
// ==============================
void syncNTP() {
  configTime(7 * 3600, 0, "pool.ntp.org", "time.nist.gov");
  Serial.print("⏰ Syncing NTP...");
  struct tm t;
  int retry = 0;
  while (!getLocalTime(&t) && retry < 20) {
    delay(500);
    Serial.print(".");
    retry++;
  }
  Serial.println(getLocalTime(&t) ? " OK!" : " FAILED");
}

void updateDateStrings() {
  struct tm t;
  if (!getLocalTime(&t))
    return;
  char dateStr[20];
  sprintf(dateStr, "%04d-%02d-%02d", t.tm_year + 1900, t.tm_mon + 1, t.tm_mday);
  current_date_str = String(dateStr);
  char monthStr[20];
  sprintf(monthStr, "%04d-%02d", t.tm_year + 1900, t.tm_mon + 1);
  current_month_str = String(monthStr);
}

// ==============================
// Weather API Fetch
// ==============================
// fetchWeather() ถูกลบออกแล้ว เพราะเราย้ายไประบบ Cloud API ที่ดึงค่าสภาพอากาศจาก Python ส่งลง Firebase แทน เพื่อแก้ปัญหาบอร์ดค้างและ Out of Memory 100%

// ==============================
// ฟังก์ชันวาดหลอด/ไอคอนต่างๆ
// ==============================
void drawGauge(int x, int y, int r, int thickness, int percent,
               uint32_t fg_color, uint32_t bg_color) {
  int end_angle = map(percent, 0, 100, 0, 360);
  for (int i = 0; i <= 360; i += 2) {
    float rad = (i - 90) * 0.0174533;
    int px = x + cos(rad) * r;
    int py = y + sin(rad) * r;
    uint32_t color = (i <= end_angle) ? fg_color : bg_color;
    tft.fillCircle(px, py, thickness / 2, color);
  }
}

void drawWifiBars(int rssi, int x, int y) {
  int bars = 0;
  if (rssi > -60)
    bars = 4;
  else if (rssi > -70)
    bars = 3;
  else if (rssi > -80)
    bars = 2;
  else if (rssi > -90)
    bars = 1;

  if (bars == last_wifi_bars && uiInited)
    return;
  last_wifi_bars = bars;

  tft.fillRect(x, y - 10, 24, 16, TFT_BLACK);
  for (int i = 0; i < 4; i++) {
    int h = 4 + (i * 3);
    uint32_t color = (i < bars) ? TFT_GREEN : 0x2104;
    tft.fillRect(x + (i * 5), y - h, 4, h, color);
  }
}

void drawPCOnlineStatus(bool online, int x, int y) {
  if (online == last_pc_online && uiInited)
    return;
  last_pc_online = online;

  tft.fillRect(x, y - 6, 50, 12, TFT_BLACK);
  tft.fillCircle(x + 4, y, 4, online ? TFT_GREEN : TFT_RED);
  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  tft.setTextSize(1);
  tft.drawString(online ? "ON" : "OFF", x + 12, y - 4);
}

void drawDuckAnim(int x, int y, int frame_idx, bool playing_game) {
    const uint16_t* ptr = nullptr;
    if (playing_game) {
        // แอนิเมชันน้องเป็ดเล่นเกม
        switch(frame_idx % 4) {
          case 0: ptr = frame_0_delay_0_07s; break;
          case 1: ptr = frame_1_delay_0_07s; break;
          case 2: ptr = frame_2_delay_0_07s; break;
          case 3: ptr = frame_3_delay_0_07s; break;
        }
    } else {
        // แอนิเมชันน้องเป็ดพิมพ์คอมพิวเตอร์
        switch(frame_idx % 4) {
          case 0: ptr = frame_0_delay_0_06s; break;
          case 1: ptr = frame_1_delay_0_06s; break;
          case 2: ptr = frame_2_delay_0_06s; break;
          case 3: ptr = frame_3_delay_0_06s; break;
        }
    }
    if (!ptr) return;
    
    // บัคแก้ไข: ลบ tft.setSwapBytes(false) ออก และขยับจุดวาดให้ปลอดภัยจากขอบจอ
    tft.pushImage(x - 32, y - 32, 64, 64, ptr);
}

void drawCatOrGame(int x, int y, bool is_gaming, String game_name) {
    drawDuckAnim(x, y, (millis() / (is_gaming ? 70 : 60)) % 4, is_gaming);
}

// ==============================
// Timer UI Function
// ==============================
// [ไฮไลต์พรีเซนต์] ระบบวาดการนับถอยหลังปิดเครื่อง เมื่อตั้งเวลา Sleep Timer จะมีแท็บคำเตือนพร้อมสีแดงกระพริบเหนือหน้าจอเพื่อเตือนผู้ใช้ล่วงหน้า
void drawTimerOverlay() {
  if (timer_left <= 0) {
    if (last_timer > 0) {
      tft.fillRect(0, 0, 320, 24, TFT_BLACK); // ลบแทบออกถ้าหมดเวลา
      uiInited = false; // บังคับวาด UI ใหม่เพื่อคืนค่า CPU/GPU/WiFi ที่โดนทับ
      last_cpu_gauge = -1; // บังคับวาดเกจใหม่ทันที
      last_gpu_gauge = -1;
      last_ram_gauge = -1;
    }
    last_timer = 0;
    return;
  }

  if (timer_left == last_timer)
    return;
  last_timer = timer_left;

  int mins = timer_left / 60;
  int secs = timer_left % 60;

  // เตือนภัย! ลากแถบแดงกระพริบด้านบนจอ
  bool blink = (secs % 2 == 0);
  tft.fillRect(0, 0, 320, 24, blink ? TFT_RED : 0x6000);
  tft.setTextColor(TFT_WHITE);
  tft.setTextSize(2);
  tft.setTextDatum(MC_DATUM);

  char timerStr[30];
  sprintf(timerStr, "SHUTDOWN IN %02d:%02d", mins, secs);
  tft.drawString(timerStr, 160, 12);
}

// ==============================
// Page 1: Top Apps & Control (TOUCH UI)

// Page 0: Dashboard (Static & Dynamic)
// ==============================
void drawStaticUI() {
  tft.fillScreen(TFT_BLACK);
  tft.drawFastVLine(160, 20, 220, 0x18E3);
  tft.drawFastHLine(0, 120, 320, 0x18E3);

  tft.setTextColor(TFT_CYAN);
  tft.setTextSize(2);
  tft.setCursor(10, 10);
  tft.print("CPU");
  tft.setTextColor(TFT_MAGENTA);
  tft.setTextSize(2);
  tft.setCursor(240, 10);
  tft.print("GPU");
  tft.setTextColor(TFT_YELLOW);
  tft.setTextSize(2);
  tft.setCursor(10, 130);
  tft.print("RAM");

  // กรอบ Time
  int box_w = 140, box_h = 65;
  int box_x = 160 - box_w / 2, box_y = 120 - box_h / 2;
  tft.fillRoundRect(box_x, box_y, box_w, box_h, 8, TFT_BLACK);
  tft.drawRoundRect(box_x, box_y, box_w, box_h, 8, TFT_CYAN);
  tft.drawRoundRect(box_x + 2, box_y + 2, box_w - 4, box_h - 4, 6, 0x035A);

  last_cpu_gauge = -1;
  last_gpu_gauge = -1;
  last_ram_gauge = -1;
  last_uptime = -1;
  last_watt = -1.0;
  last_sec = -1;
  last_wifi_bars = -1;
  last_pc_online = !pc_online;
  last_gaming_active = !gaming_active;
  last_timer = -1;
  last_weather_temp = "";
  last_weather_pm25 = "";

  uiInited = true;
}

void drawSystemInfo() {
  // ขยายพื้นที่ล้างจอจาก 40 เป็น 55 เพื่อให้ครอบคลุมตัวหนังสือทั้งบล็อก (ป้องกันสีเก่ายังค้างด้านล่าง)
  tft.fillRect(162, 160, 150, 55, TFT_BLACK);
  tft.setTextSize(1);
  tft.setTextDatum(ML_DATUM);

  // ใช้setTextColorแบบมีสีพื้นหลัง (TFT_BLACK) เพื่อให้ตัวหนังสือลบสีเก่าออกเอง 100%
  tft.setTextColor(0x07E0, TFT_BLACK);
  char dCostStr[40];
  sprintf(dCostStr, "DAY: %.1fH (%.1f B)", daily_mins_fb / 60.0, daily_cost_fb);
  tft.drawString(dCostStr, 165, 170);

  tft.setTextColor(weather_pm25_color, TFT_BLACK);
  tft.drawString(weather_pm25, 165, 185);

  // 🌤️ Weather Display
  tft.setTextColor(weather_temp_color, TFT_BLACK);
  tft.drawString(weather_icon + " " + weather_temp, 165, 200);
}

void drawDynamicUI() {
  // [ไฮไลต์พรีเซนต์] ฟังก์ชันวาดหน้าจอคอม (Dashboard) แบบไดนามิก ซึ่งจะอ่านค่าเซนเซอร์ที่สดใหม่มาแปลงเป็นเกจ (Gauge) และตัวเลขเปอร์เซ็นต์ตลอดเวลา โดยลดอาการจอกระพริบ (Flicker-Free)
  if (!uiInited)
    drawStaticUI();

  struct tm t;
  if (getLocalTime(&t)) {
    tft.setTextDatum(MC_DATUM);
    if (last_sec != t.tm_sec) {
      tft.setTextColor(TFT_WHITE, TFT_BLACK);
      tft.setTextSize(3);
      char timeStr[10];
      if (t.tm_sec % 2 == 0)
        sprintf(timeStr, "%02d:%02d", t.tm_hour, t.tm_min);
      else
        sprintf(timeStr, "%02d %02d", t.tm_hour, t.tm_min);
      tft.drawString(timeStr, 160, 112);
      last_sec = t.tm_sec;

      tft.setTextSize(1);
      tft.setTextColor(TFT_YELLOW, TFT_BLACK);
      const char *wday_name[] = {"SUN", "MON", "TUE", "WED",
                                 "THU", "FRI", "SAT"};
      char dateStr[25];
      sprintf(dateStr, "%s %02d/%02d/%04d", wday_name[t.tm_wday], t.tm_mday,
              t.tm_mon + 1, t.tm_year + 1900);
      tft.drawString(dateStr, 160, 138);
    }
  }

  // 1.5 อัปเดต สภาพอากาศ & WiFi & PC Status & Game Mode
  drawWifiBars(wifi_rssi, 296, 16);
  drawPCOnlineStatus(pc_online, 100, 15);

  // บัคแก้ไข: ลบเส้น drawCatOrGame แบบ fixed false นี้ออก 
  // เพราะใน loop() ด้านล่างมันมีคำสั่งจัดการแอนิเมชันเป็ดตามสถานะเกมรันอยู่ทุก 60ms อยู่แล้ว
  // การปล่อยตรงนี้ไว้ทำให้เป็ดเกมหายไป 1 วิแล้วโดนเป็ดพิมพ์งานแทรก

  // 2. อัปเดตตัวเลขวงกลมเกจ
  tft.setTextDatum(MC_DATUM);

  if (cpu_usage != last_cpu_gauge) {
    bool isHot = (cpu_temp > 80 || cpu_usage >= 90) && (last_sec % 2 == 0);
    drawGauge(60, 60, 30, 6, cpu_usage, isHot ? TFT_RED : TFT_CYAN, 0x035A);
    tft.fillRect(40, 45, 40, 30, TFT_BLACK);
    tft.setTextColor(TFT_WHITE, TFT_BLACK);
    tft.setTextSize(2);
    tft.drawNumber(cpu_usage, 60, 60);
    last_cpu_gauge = cpu_usage;
  }
  if (gpu_usage != last_gpu_gauge) {
    bool isHot = (gpu_temp > 80 || gpu_usage >= 90) && (last_sec % 2 == 0);
    drawGauge(260, 60, 30, 6, gpu_usage, isHot ? TFT_RED : TFT_MAGENTA, 0x4010);
    tft.fillRect(240, 45, 40, 30, TFT_BLACK);
    tft.setTextColor(TFT_WHITE, TFT_BLACK);
    tft.setTextSize(2);
    tft.drawNumber(gpu_usage, 260, 60);
    last_gpu_gauge = gpu_usage;
  }
  if (ram_usage != last_ram_gauge) {
    bool isHot = (ram_usage >= 90) && (last_sec % 2 == 0);
    drawGauge(60, 180, 30, 6, ram_usage, isHot ? TFT_RED : TFT_YELLOW, 0x5280);
    tft.fillRect(40, 165, 40, 30, TFT_BLACK);
    tft.setTextColor(TFT_WHITE, TFT_BLACK);
    tft.setTextSize(2);
    tft.drawNumber(ram_usage, 60, 180);
    last_ram_gauge = ram_usage;
  }

  tft.setTextDatum(BC_DATUM);
  tft.setTextSize(1);

  if (cpu_temp > 80 && (last_sec % 2 == 0)) {
    tft.setTextColor(TFT_RED, TFT_BLACK);
    tft.drawString("HOT!    ", 60, 110);
  } else {
    tft.setTextColor(TFT_CYAN, TFT_BLACK);
    char cTemp[15];
    sprintf(cTemp, "TEMP: %2d C", cpu_temp);
    tft.drawString(cTemp, 60, 110);
  }

  if (gpu_temp > 80 && (last_sec % 2 == 0)) {
    tft.setTextColor(TFT_RED, TFT_BLACK);
    tft.drawString("HOT!    ", 260, 110);
  } else {
    tft.setTextColor(TFT_MAGENTA, TFT_BLACK);
    char gTemp[15];
    sprintf(gTemp, "TEMP: %2d C", gpu_temp);
    tft.drawString(gTemp, 260, 110);
  }

  // Network / RAM warning
  tft.fillRect(10, 220, 100, 15, TFT_BLACK);
  if (ram_usage >= 90 && (last_sec % 2 == 0)) {
    tft.setTextColor(TFT_RED, TFT_BLACK);
    tft.drawString("RAM FULL!", 60, 230);
  } else {
    tft.setTextColor(TFT_GREEN, TFT_BLACK);
    char netStr[30];
    if (net_dl >= 10.0 || net_ul >= 10.0)
      sprintf(netStr, "D:%.0f U:%.0f M", net_dl, net_ul);
    else
      sprintf(netStr, "D:%.1f U:%.1f M", net_dl, net_ul);
    tft.drawString(netStr, 60, 230);
  }

  if (daily_mins_fb != last_uptime || pc_watt != last_watt || weather_temp != last_weather_temp || weather_pm25 != last_weather_pm25) {
    drawSystemInfo();
    last_uptime = daily_mins_fb;
    last_watt = pc_watt;
    last_weather_temp = weather_temp;
    last_weather_pm25 = weather_pm25;
  }

  drawTimerOverlay();
}

// ==============================
// ดึงค่าจาก Firebase
// ==============================
// [ไฮไลต์พรีเซนต์] หัวใจของการรับส่งข้อมูลกับ Cloud (Firebase) ดึงสถานะเครื่อง (CPU/Watt), รายชื่อโปรแกรม และคำสั่ง (Board_Command) สื่อสารกับเซิร์ฟเวอร์แบบเรียลไทม์
void fetchFirebaseData() {
  if (user_uid == "")
    return;

  if (millis() - lastSetupCheck > 30000 || !setupFetched) {
    if (Firebase.getFloat(fbdo,
                          "/users/" + user_uid + "/pc_setup/unit_price")) {
      unit_price = fbdo.floatData();
      setupFetched = true;
    }
    lastSetupCheck = millis();
  }

  updateDateStrings();

  if (Firebase.getString(fbdo,
                         "/users/" + user_uid + "/PC_Monitor/Board_Command")) {
    String cmd = fbdo.stringData();
    if (cmd == "reset_wifi") {
      Firebase.setString(
          fbdo, "/users/" + user_uid + "/PC_Monitor/Board_Command", "none");
      tft.fillScreen(TFT_RED);
      tft.setTextColor(TFT_WHITE);
      tft.setCursor(20, 100);
      tft.setTextSize(2);
      tft.print("RESETTING WIFI...");
      preferences.clear();
      delay(2000);
      ESP.restart();
    }
  }

  String path = "/users/" + user_uid + "/PC_Monitor";
  
  // ==========================================
  // [Performance Fix]: ถ้าหน้าจอหลับอยู่ ไม่ต้องดึง JSON ชุดใหญ่
  // ==========================================
  if (ssActive) {
    if (Firebase.getBool(fbdo, path + "/mouse_idle")) {
      bool newIdle = fbdo.boolData();
      // บัคแก้แล้ว: ถ้าเมาส์ขยับ (newIdle = false) และจอยังหลับอยู่ ให้ตื่น "เสมอ" ไม่ว่าก่อนหน้านี้ค่าเมาส์จะเป็นอะไรก็ตาม!
      if (!newIdle) {
        if (!isGachaPlaying) {
          ssActive = false;
          uiInited = false;
          last_pc_activity = millis(); // รีเซ็ตเวลาไม่ให้มันกลับไปหลับซ้ำทันที
          tft.fillScreen(TFT_BLACK);
          Serial.println("🖱️ Mouse Active (Wakeup fast!): สลับกลับ Dashboard");
        }
      }
      mouseIdle = newIdle;
    }
  } else {
    // === โหลด JSON ชุดใหญ่ เมื่อหน้าจอสว่างอยู่ ===
    if (Firebase.getJSON(fbdo, path)) {
      FirebaseJson &json = fbdo.jsonObject();
      FirebaseJsonData result;

      json.get(result, "CPU");
      if (result.success) {
        cpu_usage = result.intValue;
        if (cpu_usage != last_known_cpu) {
          last_known_cpu = cpu_usage;
          last_pc_activity = millis(); 
          // เพิ่มปลุกซ้อนเข้าไปให้ชัวร์ๆ เผื่อกรณีค้าง
          if (ssActive && !mouseIdle && !isGachaPlaying) {
             ssActive = false;
             uiInited = false;
             tft.fillScreen(TFT_BLACK);
          }
        }
      }
      json.get(result, "CPU_Temp");
      if (result.success)
        cpu_temp = result.intValue;
      json.get(result, "GPU");
      if (result.success)
        gpu_usage = result.intValue;
      json.get(result, "GPU_Temp");
      if (result.success)
        gpu_temp = result.intValue;
      json.get(result, "RAM");
      if (result.success)
        ram_usage = result.intValue;
      json.get(result, "Watt");
      if (result.success) {
        if (result.typeNum == FirebaseJson::JSON_INT) pc_watt = (float)result.intValue;
        else pc_watt = result.doubleValue;
      }
      json.get(result, "online");
      if (result.success)
        pc_online = result.boolValue;
      json.get(result, "Net_DL_Mbps");
    if (result.success)
      net_dl = result.doubleValue;
    json.get(result, "Net_UL_Mbps");
    if (result.success)
      net_ul = result.doubleValue;

    // Timer
    json.get(result, "Timer_Left_Secs");
    if (result.success)
      timer_left = result.intValue;
    else
      timer_left = 0;

    // Top CPU Apps
    for (int i = 0; i < 3; i++) {
      json.get(result, "Top_Apps/[" + String(i) + "]/name");
      if (result.success) {
        String name = result.stringValue;
        if (name.length() > 9)
          name = name.substring(0, 9);
        json.get(result, "Top_Apps/[" + String(i) + "]/cpu");
        top_cpu_apps[i] = name + " " + String(result.intValue) + "%";
      } else
        top_cpu_apps[i] = "---";
    }

    // Top RAM Apps
    for (int i = 0; i < 3; i++) {
      json.get(result, "Top_RAM_Apps/[" + String(i) + "]/name");
      if (result.success) {
        String name = result.stringValue;
        if (name.length() > 9)
          name = name.substring(0, 9);
        json.get(result, "Top_RAM_Apps/[" + String(i) + "]/ram_gb");
        top_ram_apps[i] = name + " " + String(result.doubleValue, 1) + "G";
      } else
        top_ram_apps[i] = "---";
    }

    json.get(result, "mouse_idle");
    if (result.success) {
      bool newIdle = result.boolValue;
      if (newIdle && !mouseIdle) {
        if (!isGameIntroPlaying) {
          ssActive = true;
          ssShowClock = true;
          ssClockInited = false;     
          ssLastSwitch = millis();
          ssStartTime = millis();
          animeFrame = 0;
          tft.fillScreen(TFT_BLACK); 
          Serial.println("💤 Mouse Idle: สลับเป็นหน้านาฬิกา");
        }
      } else if (!newIdle) {
        // บัคแก้แล้ว: ตื่นเสมอถ้าได้ข้อมูลว่าเมาส์กำลังขยับ!
        if (ssActive && !isGachaPlaying) { 
          ssActive = false;
          uiInited = false;            
          last_pc_activity = millis(); // รีเซ็ตเวลาไม่ให้กลับไปหลับซ้ำทันที
          tft.fillScreen(TFT_BLACK);
          Serial.println("🖱️ Mouse Active: สลับกลับ Dashboard");
        }
      }
      mouseIdle = newIdle;
    }
    }
  } // <- ปิดวงเล็บของ else (ดึงข้อมูลแบบเต็ม)

  // อ่านค่า Weather จากที่ Python ส่งขึ้น Firebase (คอมพิวเตอร์ต้องออฟไลน์หรือไม่มีข้อมูลก็จะกลายเป็น -- อัตโนมัติ)
  String pathWeather = "/users/" + user_uid + "/weather_alert";
  if (Firebase.getJSON(fbdo, pathWeather)) {
    FirebaseJson &jsonW = fbdo.jsonObject();
    FirebaseJsonData resultW;
    
    jsonW.get(resultW, "temp_c");
    if (resultW.success) {
      float t = (resultW.typeNum == FirebaseJson::JSON_INT) ? (float)resultW.intValue : resultW.doubleValue;
      if (t > -90.0) {
        weather_temp = String(t, 1) + " C";
        weather_temp_color = (t >= 30.0) ? TFT_RED : TFT_CYAN;
      }
    } else {
      weather_temp = "--";
    }

    jsonW.get(resultW, "weather_code");
    if (resultW.success) {
      int code_w = resultW.intValue;
      if (code_w == 0) weather_icon = "Sunny";
      else if (code_w <= 3) weather_icon = "Cloudy";
      else if (code_w <= 48) weather_icon = "Foggy";
      else if (code_w <= 67) weather_icon = "Rain";
      else if (code_w <= 79) weather_icon = "Snow";
      else if (code_w <= 99) weather_icon = "Storm";
      else weather_icon = "??";
    }

    jsonW.get(resultW, "pm25_val");
    if (resultW.success) {
      float pm = (resultW.typeNum == FirebaseJson::JSON_INT) ? (float)resultW.intValue : resultW.doubleValue;
      if (pm >= 0) {
        if (pm <= 15.0) weather_pm25_color = TFT_CYAN;     
        else if (pm <= 25.0) weather_pm25_color = TFT_GREEN;  
        else if (pm <= 37.5) weather_pm25_color = TFT_YELLOW; 
        else if (pm <= 75.0) weather_pm25_color = TFT_ORANGE; 
        else weather_pm25_color = TFT_RED;                             
        weather_pm25 = "PM2.5: " + String(pm, 1) + " ug/m3";
      }
    } else {
      weather_pm25 = "--";
      weather_pm25_color = TFT_WHITE;
    }
  } else {
    // ถ้าคอมดับ หรือเน็ตตัด ให้ขึ้นข้อความลบไว้ตามที่คุณรีเควส
    weather_temp = "--";
    weather_pm25 = "--";
    weather_pm25_color = TFT_WHITE;
  }

  if (current_date_str != "") {
    String pathDay =
        "/users/" + user_uid + "/daily_summary/" + current_date_str;
    if (Firebase.getJSON(fbdo, pathDay)) {
      FirebaseJson &json = fbdo.jsonObject();
      FirebaseJsonData result;
      json.get(result, "session_mins");
      if (result.success)
        daily_mins_fb = result.intValue;
      json.get(result, "cost_thb");
      if (result.success)
        daily_cost_fb = result.doubleValue;
    }
  }

  String pathGame = "/users/" + user_uid + "/gaming_mode";
  if (Firebase.getJSON(fbdo, pathGame)) {
    FirebaseJson &json = fbdo.jsonObject();
    FirebaseJsonData result;
    json.get(result, "active");
    if (result.success)
      gaming_active = result.boolValue;
    json.get(result, "game");
    if (result.success) {
      gaming_game_name = result.stringValue;
      
      bool shouldShowGaming = (gaming_active && gaming_game_name != "");
      
      // ถ้าเริ่มเกมใหม่
      if (shouldShowGaming && gaming_game_name != currentGame) {
        currentGame = gaming_game_name;
        isGameIntroPlaying = true;
        gameIntroStart = millis();
        ssActive = false; // ปิดนาฬิกา
        uiInited = false;
        tft.fillScreen(TFT_BLACK);
        Serial.println("🎮 เริ่มเกม: " + currentGame + " (แสดง Intro 10 วิ)");
      } else if (!shouldShowGaming && currentGame != "") {
        currentGame = ""; // เลิกเล่น
        if (isGameIntroPlaying) {
            isGameIntroPlaying = false;
            uiInited = false;
        }
      }
    }
  }

  // ==========================
  // Weather Alert Check
  // ==========================
  static unsigned long lastWeatherAlertCheck = 0;
  if (millis() - lastWeatherAlertCheck > 15000) {
    lastWeatherAlertCheck = millis();
    String pathWeather = "/users/" + user_uid + "/weather_alert";
    if (Firebase.getJSON(fbdo, pathWeather)) {
      FirebaseJson &json = fbdo.jsonObject();
      FirebaseJsonData result;
      
      json.get(result, "rain");
      bool current_rain = result.success ? result.boolValue : false;
      
      json.get(result, "pm25");
      bool current_pm25 = result.success ? result.boolValue : false;
      
      // Trigger Rain Alert (Transitions from false to true)
      if (current_rain && !rain_active) {
        isWeatherIntroPlaying = true;
        weatherIntroType = 1;
        weatherIntroStart = millis();
        ssActive = false;
        uiInited = false;
        tft.fillScreen(TFT_BLACK);
        Serial.println("🌧️ แจ้งเตือนฝนตก! (แสดง 10 วินาที)");
      }
      
      // Trigger PM2.5 Alert (Transitions from false to true)
      if (current_pm25 && !pm25_active && !isWeatherIntroPlaying) {
        isWeatherIntroPlaying = true;
        weatherIntroType = 2;
        weatherIntroStart = millis();
        ssActive = false;
        uiInited = false;
        tft.fillScreen(TFT_BLACK);
        Serial.println("😷 แจ้งเตือนฝุ่น PM2.5! (แสดง 10 วินาที)");
      }

      rain_active = current_rain;
      pm25_active = current_pm25;
    }
  }
}

// ==============================
// Gaming Mode UI
// ==============================
void drawGameIntroAnim(unsigned long frame) {
  // เคลียร์จอเฉพาะตอนเฟรมแรกสุด เพื่อไม่ให้จอกระพริบ
  if (frame == 0) tft.fillScreen(TFT_BLACK);

  // คณิตศาสตร์วงกลม (ตรีโกณมิติ)
  int cx = 160;
  int cy = 120;
  int r = 50;

  // วาดชื่อเกม
  tft.fillRect(0, 0, 320, 40, TFT_BLACK);
  tft.setTextColor(0x07FF, TFT_BLACK); // Cyan
  tft.setTextSize(2);
  tft.setTextDatum(MC_DATUM);
  tft.drawString("LAUNCHING...", 160, 15);
  
  tft.setTextColor(0xFFE0, TFT_BLACK); // Yellow
  tft.drawString(currentGame, 160, 210);

  // วาดกรอบไกด์บางๆ (สปินเนอร์รัศมี)
  tft.drawCircle(cx, cy, r, TFT_BLACK);
  tft.drawCircle(cx, cy, r, TFT_DARKGREY);

  // เคลียร์วงกลมด้านในเพื่อลบรอยหมุนเดิมบางส่วน 
  tft.fillCircle(cx, cy, r-1, TFT_BLACK);

  // จุดเชื่อมวิ่งวนรอบด้วย cos, sin
  for (int i = 0; i < 3; i++) {
    float angle = (frame * 15 + (i * 120)) * 3.14159 / 180.0;
    int x = cx + r * cos(angle);
    int y = cy + r * sin(angle);
    tft.fillCircle(x, y, 6, TFT_MAGENTA);
  }
}

// ==============================
// Weather Alert Animation (Geometric Shapes)
// ==============================
void drawWeatherIntroAnim(int type, unsigned long timeElapsed) {
  if (timeElapsed < 200) tft.fillScreen(TFT_BLACK);

  String alertText = "";
  uint32_t textColor = TFT_WHITE;

  if (type == 1) { // 🌧️ Rain Alert
    alertText = "RAINING NOW!";
    textColor = TFT_CYAN;

    // เคลียร์จอท่อนล่างเพื่อรีเฟรชเส้นฝน
    tft.fillRect(0, 50, 320, 190, TFT_BLACK);

    // วาดก้อนเมฆ (วงกลมซ้อนกัน)
    tft.fillCircle(120, 100, 30, TFT_DARKGREY);
    tft.fillCircle(160, 80, 40, TFT_LIGHTGREY);
    tft.fillCircle(200, 100, 30, TFT_DARKGREY);

    // วาดเม็ดฝนตก
    int rainOffset = (timeElapsed / 20) % 50;
    for (int i = 0; i < 6; i++) {
      int rx = 100 + (i * 25);
      int ry = 130 + rainOffset + (i % 2) * 20;
      if (ry < 240) {
        tft.drawLine(rx, ry, rx - 10, ry + 20, TFT_CYAN);
        tft.drawLine(rx+1, ry, rx - 9, ry + 20, TFT_CYAN);
      }
    }
  } else if (type == 2) { // 😷 PM2.5 Alert
    alertText = "PM 2.5 DANGER!";
    textColor = TFT_ORANGE;
    
    // วาดแค่ครั้งเดียว ไม่ต้องรีเฟรช 
    if (timeElapsed < 500) {
      tft.fillScreen(TFT_BLACK);
      tft.fillTriangle(160, 60, 100, 180, 220, 180, TFT_YELLOW); // ป้ายเตือน
      tft.fillRect(155, 100, 10, 40, TFT_BLACK); // เครื่องหมายตกใจจุดบน
      tft.fillCircle(160, 160, 6, TFT_BLACK);    // จุดล่าง
    }
  }

  // แถบข้อความด้านบน
  tft.fillRect(0, 0, 320, 40, TFT_BLACK);
  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  tft.setTextSize(2);
  tft.setTextDatum(MC_DATUM);
  tft.drawString("WEATHER ALERT", 160, 10);
  tft.setTextColor(textColor, TFT_BLACK);
  tft.drawString(alertText, 160, 32);
}

// ==============================
// 🔮 Gacha Quote (คำคมสุ่ม)
// ==============================
void drawMagicDuckQuote() {
  tft.fillScreen(TFT_WHITE); // พื้นหลังสีขาวตามที่ขอ
  
  // วาดรูปจากไฟล์ MagicDuckQuote.h (สุ่มรูปจากทั้งหมด 6 รูปที่คุณใส่มา)
  tft.setSwapBytes(false); 
  
  const uint16_t* quoteImages[] = {O_o, image_Photoroom_, image_1, image_2, image_just, image_3};
  int imgIndex = random(0, 6);
  
  // ปรับตำแหน่งให้รูปใหญ่ขึ้น (240x240) อยู่กลางจอพอดี (จอ 320x240)
  // x = (320-240)/2 = 40, y = (240-240)/2 = 0
  tft.pushImage(40, 0, 240, 240, quoteImages[imgIndex]); 
}

// ==============================
// WebSocket Events
// ==============================
void onWebSocketEvent(WStype_t type, uint8_t *payload, size_t length) {
  switch (type) {
  case WStype_CONNECTED:
    wsConnected = true;
    Serial.println("✅ WebSocket เชื่อมต่อ...");
    if (user_uid != "")
      wsClient.sendTXT("{\"uid\":\"" + user_uid + "\"}");
    break;
  case WStype_DISCONNECTED:
    wsConnected = false;
    break;
  default:
    break;
  }
}

// ==============================
// Screensaver
// ==============================
// ฟังก์ชันวาดเป็ดนอนหลับ 200x200 แบบ row-by-row ไม่กินแรม
void drawSleepingDuck(int cx, int cy, int frame_idx) {
    const uint16_t* ptr = nullptr;
    switch(frame_idx % 7) {
      case 0: ptr = frame_00_delay_0_1s; break;
      case 1: ptr = frame_01_delay_0_1s; break;
      case 2: ptr = frame_02_delay_0_1s; break;
      case 3: ptr = frame_03_delay_0_1s; break;
      case 4: ptr = frame_04_delay_0_1s; break;
      case 5: ptr = frame_05_delay_0_1s; break;
      case 6: ptr = frame_06_delay_0_1s; break;
    }
    if (!ptr) return;
    
    int startX = cx - 100;
    int startY = cy - 100;
    tft.setSwapBytes(false);
    tft.pushImage(startX, startY, 200, 200, ptr);
}

// หน้าจอหลักเมื่อ PC ออฟไลน์: เป็ดนอน + นาฬิกาสวยๆ
void drawSS_DuckClock(unsigned long frame) {
  struct tm t;
  // บัคแก้แล้ว: ใส่ timeout 10ms ป้องกันบอร์ดค้าง 5 วินาทีเวลารอเวลาจากเน็ต
  bool gotTime = getLocalTime(&t, 10); 

  bool isInit = false;
  if (!ssClockInited) {
    tft.fillScreen(TFT_BLACK);
    ssClockInited = true;
    last_wifi_bars = -1;
    last_sec = -1;
    isInit = true;
  }

  // === ย้ายเป็ดลงล่างสุด (center y=175) ===
  // วาดเป็ดก่อนเสมอ เพื่อให้เป็ดห้ามค้างแม้ว่าจะหลุดเน็ตก็ตาม!
  drawSleepingDuck(160, 175, frame);

  if (!gotTime) return; // ถ้าไม่ได้เวลา ค่อยข้ามการวาดนาฬิกา


  // === ตัวเลขนาฬิกา: วาดแค่ตอนเวลาเปลี่ยนจริงๆ + มี Bg ดำ = ภาพนิ่งสนิท 100% ===
  int encoded = t.tm_hour * 100 + t.tm_min;
  bool minuteChanged = isInit || (last_sec != encoded);
  if (minuteChanged) {
    last_sec = encoded;
    
    tft.setTextDatum(MC_DATUM);

    // ชั่วโมง
    tft.setTextColor(0x07FF, TFT_BLACK); // ใช้ bg สีดำได้เลย เพราะไม่โดนเป็ดลบแล้ว
    tft.setTextSize(6);
    char timeH[4];
    sprintf(timeH, "%02d", t.tm_hour);
    tft.drawString(timeH, 105, 34);

    // นาที
    tft.setTextColor(0xFD20, TFT_BLACK);
    tft.setTextSize(6);
    char timeM[4];
    sprintf(timeM, "%02d", t.tm_min);
    tft.drawString(timeM, 215, 34);
  }

  // === จุดกะพริบวินาที วาดแค่ตอนเปลี่ยนวินาที ===
  static int lastColonSec = -1;
  if (t.tm_sec != lastColonSec || isInit) {
    lastColonSec = t.tm_sec;
    tft.setTextDatum(MC_DATUM);
    tft.setTextColor(0xFFE0, TFT_BLACK);
    tft.setTextSize(6);
    if (t.tm_sec % 2 == 0) {
      tft.drawString(":", 160, 31);
    } else {
      tft.drawString(" ", 160, 31);
    }
  }

  // === ข้อมูลด้านล่าง ย้ายไปใต้เวลาด้านบน (ตามบรีฟ) ===
  static int lastAfkMin = -1;
  unsigned long afkMins = (millis() - ssStartTime) / 60000;
  if (minuteChanged || (int)afkMins != lastAfkMin) {
    lastAfkMin = (int)afkMins;

    tft.setTextDatum(MC_DATUM);
    tft.setTextSize(1);

    // รวมทุกอย่างไว้แถวเดียว (วันที่ | AFK | ค่าไฟ | อุณหภูมิ | ฝุ่น)
    tft.setTextDatum(MC_DATUM);
    tft.setTextSize(1);
    
    // 1. วันที่
    tft.setTextColor(0x7BEF, TFT_BLACK);
    char dateStr[12];
    sprintf(dateStr, "%02d/%02d/%02d", t.tm_mday, t.tm_mon + 1, (t.tm_year + 1900) % 100);
    tft.drawString(dateStr, 35, 68);

    // 2. AFK (ชม.)
    tft.setTextColor(0xFB8A, TFT_BLACK);
    char afkStr[12];
    sprintf(afkStr, "%.1fH", afkMins / 60.0);
    tft.drawString(afkStr, 95, 68); 

    // 3. ค่าไฟ
    tft.setTextColor(0x07E0, TFT_BLACK);
    char costStr[12];
    sprintf(costStr, "%.1fB", daily_cost_fb);
    tft.drawString(costStr, 155, 68);

    // 4. อุณหภูมิ
    tft.setTextColor(weather_temp_color, TFT_BLACK);
    String tempShort = weather_temp;
    tempShort.replace(" C", ""); 
    tft.drawString(tempShort + "C", 220, 68);

    // 5. ฝุ่น PM2.5 (ตัดหน่วย ug/m3 ทิ้ง เพื่อให้เว้นวรรคได้กว้างและไม่เบียดตัวเลขอุณหภูมิ)
    tft.setTextColor(weather_pm25_color, TFT_BLACK);
    String pmShort = weather_pm25;
    pmShort.replace("PM2.5: ", "PM:"); 
    pmShort.replace(" ug/m3", ""); 
    tft.drawString(pmShort, 290, 68);
  }

  // WiFi & Timer (wifi ย้ายไปชิดริมขวา y=15 เพื่อหลบเป็ดชัวร์ๆ)
  drawWifiBars(wifi_rssi, 295, 15);
  drawTimerOverlay();
}

// ==============================
// UDP & AP Setup
// ==============================
void drawWifiSetupScreen() {
  tft.fillScreen(TFT_BLACK);
  tft.fillRect(0, 0, 320, 30, 0x180E);
  tft.setTextColor(TFT_CYAN);
  tft.setTextSize(2);
  tft.setCursor(8, 7);
  tft.print("WIFI SETUP");
  tft.setTextSize(1);
  tft.setTextColor(TFT_WHITE);
  tft.setCursor(8, 50);
  tft.print("Connect to WiFi:");
  tft.setTextColor(TFT_YELLOW);
  tft.setCursor(8, 65);
  tft.print(">> BOARD_SETUP <<");
  tft.setTextColor(0x8410);
  tft.setCursor(8, 90);
  tft.print("192.168.4.1");
}

void findPCviaUDP() {
  udp.begin(UDP_PORT);
  tft.fillScreen(TFT_BLACK);
  tft.fillRect(0, 0, 320, 30, 0x180E);
  tft.setTextColor(TFT_CYAN);
  tft.setTextSize(2);
  tft.setCursor(8, 7);
  tft.print("SEARCHING PC...");

  unsigned long start = millis();
  while (millis() - start < 15000) {
    int packetSize = udp.parsePacket();
    if (packetSize) {
      char buf[128] = {0}; // ขยายบัฟเฟอร์รองรับ UID ยาวๆ
      udp.read(buf, sizeof(buf) - 1);
      String msg = String(buf);
      
      // ข้อความแบบใหม่: RECHARGE:[IP]:[PORT]:[UID]
      if (msg.startsWith("RECHARGE:")) {
        int c1 = msg.indexOf(':', 9);
        if (c1 > 0) {
          String ip = msg.substring(9, c1);
          int c2 = msg.indexOf(':', c1 + 1);
          
          if (c2 > 0) {
            // ระบบกรอง UID (อัปเดตใหม่ ป้องกันบอร์ดจับติดเครื่องคนอื่นใน WiFi เดียวกัน)
            String broadcast_uid = msg.substring(c2 + 1);
            broadcast_uid.trim();
            if (broadcast_uid != user_uid) {
              continue; // UID ไม่ตรง แปลว่าเป็นคอมพิวเตอร์เครื่องอื่น ข้ามไปเลยยย!
            }
          }
          
          pcHost = ip;
          pcFound = true;
          udp.stop();
          delay(500);
          return;
        }
      }
    }
    delay(100);
  }
  udp.stop();
}

void redirectToHome() {
  server.sendHeader("Location", "http://192.168.4.1/", true);
  server.send(302, "text/plain", "");
}

void startAPMode() {
  isAPMode = true;
  WiFi.mode(WIFI_AP);
  WiFi.softAPConfig(apIP, apIP, IPAddress(255, 255, 255, 0));
  WiFi.softAP("BOARD_SETUP");
  delay(500);
  drawWifiSetupScreen();
  dnsServer.setErrorReplyCode(DNSReplyCode::NoError);
  dnsServer.setTTL(0);
  dnsServer.start(DNS_PORT, "*", apIP);
  server.on("/", HTTP_GET, []() { server.send(200, "text/html", index_html); });
  server.on("/save", HTTP_POST, []() {
    preferences.putString("ssid", server.arg("ssid"));
    preferences.putString("password", server.arg("password"));
    preferences.putString("uid", server.arg("uid"));
    server.send(200, "text/html",
                "<html><body "
                "style='background:#5b4fcf;color:#fff;text-align:center;"
                "padding:50px;'><h2>OK! Restarting...</h2></body></html>");
    delay(3000);
    ESP.restart();
  });
  server.onNotFound(redirectToHome);
  server.begin();
}

// ==============================
// Setup
// ==============================
void setup() {
  Serial.begin(115200);
  tft.init();
  tft.setRotation(1);
  tft.fillScreen(TFT_BLACK);

  // ==============================
  // BOOT Button: กดค้างตอนเปิดเครื่อง = ล้างค่าทันที
  // ==============================
  pinMode(BOOT_BTN_PIN, INPUT_PULLUP);
  if (digitalRead(BOOT_BTN_PIN) == LOW) {
    // กดค้างตอน power on = force reset
    tft.fillScreen(TFT_BLACK);
    tft.setTextDatum(MC_DATUM);
    tft.setTextColor(TFT_RED, TFT_BLACK);
    tft.setTextSize(2);
    tft.drawString("FACTORY RESET", 160, 100);
    tft.setTextColor(TFT_WHITE, TFT_BLACK);
    tft.setTextSize(1);
    tft.drawString("Clearing WiFi & UID...", 160, 125);
    delay(1500);
    preferences.begin("wifi_setup", false);
    preferences.clear();
    preferences.end();
    tft.setTextColor(TFT_GREEN, TFT_BLACK);
    tft.drawString("Done! Opening WiFi Setup...", 160, 145);
    delay(1000);
    ESP.restart();
  }

  preferences.begin("wifi_setup", false);
  ssid = preferences.getString("ssid", "");
  password = preferences.getString("password", "");
  user_uid = preferences.getString("uid", "");

  if (ssid != "") {
    WiFi.mode(WIFI_STA);
    WiFi.begin(ssid.c_str(), password.c_str());
    int attempts = 0;
    while (WiFi.status() != WL_CONNECTED && attempts < 20) {
      delay(500);
      attempts++;
    }

    if (WiFi.status() == WL_CONNECTED) {
      config.database_url = FIREBASE_HOST;
      config.signer.tokens.legacy_token = FIREBASE_AUTH;
      Firebase.begin(&config, &auth);
      Firebase.reconnectWiFi(true);

      syncNTP();
      findPCviaUDP();

      if (pcFound) {
        wsClient.begin(pcHost.c_str(), WS_PORT, "/");
        wsClient.onEvent(onWebSocketEvent);
        wsClient.setReconnectInterval(3000);
      }
      
      // 🌟 บังคับให้บอร์ดเปิดมาปุ๊บ เป็นหน้านาฬิกาเลย 
      ssActive = true; 
      tft.fillScreen(TFT_BLACK);
      
      return;
    }
  }
  startAPMode();
}

// ==============================
// Loop
// ==============================
unsigned long lastWifiCheck = 0;
int wifiRetryCount = 0;

void loop() {
  // ==============================
  // BOOT Button Hold: กดค้าง 3 วิ = Factory Reset
  // ==============================
  if (digitalRead(BOOT_BTN_PIN) == LOW) {
    if (!bootBtnWasPressed) {
      bootBtnWasPressed = true;
      bootBtnPressStart = millis();
    } else {
      unsigned long held = millis() - bootBtnPressStart;
      if (held >= 3000) {
        // กดค้างครบ 3 วิ → ล้างค่าและ restart
        tft.fillScreen(TFT_BLACK);
        tft.setTextDatum(MC_DATUM);
        tft.setTextColor(TFT_RED, TFT_BLACK);
        tft.setTextSize(2);
        tft.drawString("RESETTING...", 160, 90);
        tft.setTextColor(TFT_WHITE, TFT_BLACK);
        tft.setTextSize(1);
        tft.drawString("Clearing WiFi & UID...", 160, 115);
        delay(1000);
        preferences.begin("wifi_setup", false);
        preferences.clear();
        preferences.end();
        tft.setTextColor(TFT_GREEN, TFT_BLACK);
        tft.drawString("Done! Restarting...", 160, 135);
        delay(1000);
        ESP.restart();
      } else if (held > 500) {
        // วาด countdown bar บนหน้าจอ
        int pct = (held * 100) / 3000;
        tft.fillRect(10, 228, 300, 10, 0x2104);
        tft.fillRect(10, 228, pct * 3, 10, TFT_RED);
        tft.setTextDatum(MC_DATUM);
        tft.setTextColor(TFT_RED, TFT_BLACK);
        tft.setTextSize(1);
        tft.drawString("Hold to Reset...", 160, 222);
      }
    }
  } else {
    if (bootBtnWasPressed) {
      unsigned long held = millis() - bootBtnPressStart;
      if (held < 500) {
        // บัคแก้ไข: วางฟังก์ชันกดสั้น (Short Press) เพื่อให้หน้าจอเปลี่ยนสลับได้จริง
        current_page = (current_page == 0) ? 1 : 0;
        uiInited = false;
        tft.fillScreen(TFT_BLACK);
      } else {
        // ปล่อยปุ่มแบบกดค้างไม่ถึง 3 วิ → ลบแถบนับถอยหลังออก
        tft.fillRect(0, 215, 320, 25, TFT_BLACK);
      }
      bootBtnWasPressed = false;
    }
  }

  if (isAPMode) {
    dnsServer.processNextRequest();
    server.handleClient();
    return;
  }

  wsClient.loop();
  
  // บัคแก้ไข: เอา current_page = 0; ออกเพื่อไม่ให้จอถูกล็อคหน้าเดียว


  // ===== SCREENSAVER =====
  if (ssActive) {
    if (isGachaPlaying) {
      if (millis() - gachaIntroStart >= 120000) { 
        isGachaPlaying = false;
        uiInited = false;
        ssClockInited = false;
        tft.fillScreen(TFT_BLACK);
      }
    } else {
      static unsigned long lastGachaCheck = 0;
      if (millis() - lastGachaCheck > 10000) {
        bool trigger = false;
        #if GACHA_TEST_MODE
          trigger = true; 
        #else
          // สุ่ม 1 ใน 5000 ทุกๆ 10 วินาที จะมีค่าเฉลี่ยออกมาประมาณ 1.7 ครั้งต่อวัน (ถ้าเปิดเครื่องทั้งวัน)
          if (random(1, 5001) <= 1) trigger = true; 
        #endif

        if (trigger) {  
           isGachaPlaying = true;
           gachaIntroStart = millis();
           drawMagicDuckQuote(); 
        }
        lastGachaCheck = millis();
      }
      }
      
      // ลบระบบ UDP ออก และพึ่งพาเงื่อนไขจับเวลาแอนิเมชันอย่างเดียว

      // แก้ความเร็วของเป็ดให้นอนสมูทขึ้น เปลี่ยนทุกๆ 0.5 วินาที (500ms) ตามค่าที่แนะนำ
      if (!isGachaPlaying && (millis() - lastDraw > 500)) {
        drawSS_DuckClock(animeFrame++);
        if (animeFrame >= 7) animeFrame = 0;
        lastDraw = millis();
      }
    
    // ===============================================
    // กลับมาใช้ระบบ Firebase เช็คการขยับเมาส์เหมือนเดิม (ตามรีเควส) แต่เพิ่มการเช็ค CPU เปลี่ยนแปลงเพื่อหลุดพ้นจากลูป Deadlock (บัคลืมค่าเก่า)
    // ===============================================
    if (millis() - lastFbCheck > 3000) {
      bool wakeup = false;

      // ดึงค่า 1: เมาส์
      if (Firebase.getBool(fbdo, "/users/" + user_uid + "/PC_Monitor/mouse_idle")) {
        bool newIdle = fbdo.boolData();
        if (!newIdle && mouseIdle) wakeup = true;
        mouseIdle = newIdle;
      }

      // ดึงค่า 2: CPU (เหมือนโค้ดเก่าเป๊ะๆ ที่ใช้ CPU เป็นตัวปลุกสำรอง แต่ตอนนี้ดึงมาแค่ค่าเดียว เล็กนิดเดียว ไม่กระตุก!)
      if (Firebase.getInt(fbdo, "/users/" + user_uid + "/PC_Monitor/CPU")) {
        int newCpu = fbdo.intData();
        if (newCpu != last_known_cpu) {
          last_known_cpu = newCpu;
          if (!mouseIdle) wakeup = true;
        }
      }

      if (wakeup && !isGachaPlaying) {
          ssActive = false;
          uiInited = false;
          last_pc_activity = millis();
          tft.fillScreen(TFT_BLACK);
          Serial.println("🌐 FIREBASE WAKEUP (เมาส์ขยับ หรือ CPU ดันจอให้ตื่น ปลุกสำเร็จ!)");
      }
      
      lastFbCheck = millis();
    }
    
    return; 
  }
  // ===== END SCREENSAVER =====

  // ดำเนินการ Firebase + UI ตามปกติ (ถ้าไม่ใช่ Screensaver)
  if (millis() - lastFbCheck > 2000) {
    fetchFirebaseData();
    lastFbCheck = millis();
    wifi_rssi = WiFi.RSSI();
  }

  // นำ fetchWeather() ออกจาก Loop แล้ว เพราะบอร์ดไม่ได้เป็นคนดึงข้อมูลสภาพอากาศเองอีกต่อไป

  // Auto-Sleep Computer State
  if (!ssActive && !isGameIntroPlaying && (millis() - last_pc_activity > 15000)) {
    ssActive = true;
    ssLastSwitch = millis();
    animeFrame = 0;
    ssClockInited = false;
    tft.fillScreen(TFT_BLACK);
    Serial.println("💤 คอมพิวเตอร์ออฟไลน์! ตัดเข้าสู่หน้านาฬิกา");
  }

  // Weather Alert Animation Loop
  if (isWeatherIntroPlaying) {
    unsigned long timeElapsed = millis() - weatherIntroStart;
    if (timeElapsed < 10000) {
      if (millis() - lastDraw > 100) {
        drawWeatherIntroAnim(weatherIntroType, timeElapsed);
        lastDraw = millis();
      }
      return;
    } else {
      isWeatherIntroPlaying = false;
      uiInited = false;
      tft.fillScreen(TFT_BLACK);
      animeFrame = 0;
    }
  }

  // Game Intro Animation Loop
  if (isGameIntroPlaying) {
    if (millis() - gameIntroStart < 10000) {
      if (millis() - lastDraw > 80) {
        drawGameIntroAnim(animeFrame++);
        lastDraw = millis();
      }
      return;
    } else {
      isGameIntroPlaying = false;
      uiInited = false;
      tft.fillScreen(TFT_BLACK);
      animeFrame = 0;
    }
  }

  if (millis() - lastDraw > 1000) {
    if (!ssActive && !isGameIntroPlaying) {
      drawDynamicUI();
    }
    lastDraw = millis();
  }

  static unsigned long lastDuckDraw = 0;
  // ปรับรีเฟรชเรทเป็ดแอนิเมชั่นให้วาดถี่ขึ้น (จาก 60ms เป็น 30ms เพื่อให้เนียนตาขึ้น ไม่กระตุกจากเฟรมเรทชนกัน)
  if (!ssActive && !isGameIntroPlaying && current_page == 0 && (millis() - lastDuckDraw > 30)) {
     // ขยับพิกัดน้องเป็ดนิดหน่อยเพื่อให้เห็นครบตัว ไม่หลุดขอบจอ (320x240)
     drawCatOrGame(280, 205, gaming_active, gaming_game_name);
     lastDuckDraw = millis();
  }

  if (millis() - lastWifiCheck > 5000) {
    lastWifiCheck = millis();
    if (WiFi.status() != WL_CONNECTED) {
      wifiRetryCount++;
      WiFi.reconnect();
      if (wifiRetryCount >= 3) {
        wifiRetryCount = 0;
        startAPMode();
      }
    } else {
      wifiRetryCount = 0;
    }
  }
}
